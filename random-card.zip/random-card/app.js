window.onload = function() {
  let flipEl = document.querySelector('.flip');
  let suiteEls = document.querySelectorAll('.suite');
  let numberEl = document.querySelector('.number');
  let countdownEl = document.querySelector('.countdown');
  let progressEl = document.getElementById('progressBar');

  flipEl.addEventListener('click', flipIt);

  // flip card
  function flipIt() {
    const suites = ['heart', 'spade', 'club', 'diamond'];
    function ranNum(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    }
    const newNum = ranNum(2, 10);
    numberEl.innerHTML = newNum;

    function getRandomItem(arr) {
      const randomIndex = Math.floor(Math.random() * arr.length);
        const item = arr[randomIndex];
      return item;
    }
    const result = getRandomItem(suites);
    
    for (const suiteEl of suiteEls) {
      suiteEl.src = `img/${result}.svg`;
    }
    console.log(result);
  }

  // timer
  let timeleft = 10;
  let downloadTime = setInterval(function() {
    if (timeleft <= 0) {
      flipIt();
      clearInterval(downloadTime);
    }
    progressEl.value = 10 - timeleft;
    timeleft -= 1;
    countdownEl.innerHTML = timeleft + 1;
  }, 1000);
  setInterval(downloadTime);

  // change dimensions
  let widthEl = document.getElementById('width');
  let heightEl = document.getElementById('height');
  let submitEl = document.getElementById('submit');
  submitEl.addEventListener('click', changeWidth);

  function changeWidth() {
    document.querySelector('.card').style.width = widthEl.value + 'px';
    document.querySelector('.card').style.height = heightEl.value + 'px';
  }
  
};